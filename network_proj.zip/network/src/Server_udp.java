
import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class Server_udp {
	static VigenereCipher v;

	public static void main(String[] args) {

		ClientServerUtility utility = new ClientServerUtility();
		int serverPortNumber = 1027;
		String responseToBeSent = "";
		byte[] responseToBeSentInBytes;
		InetAddress ipAddressOfClient = null;
		try {
			ipAddressOfClient = InetAddress.getLocalHost();
		} catch (UnknownHostException e1) {
			e1.printStackTrace();
		}

		System.out.println("The server is waiting for client to send the request:");
		try {
			DatagramSocket serverSocket = new DatagramSocket(serverPortNumber);
			byte[] receivedRequest = new byte[100000];

			while (true) {
				DatagramPacket receivedData = new DatagramPacket(receivedRequest, receivedRequest.length);
				String receivedDataString = receiveRequest(receivedRequest, serverSocket, receivedData);
				System.out.printf("\n\nReceived request : \n%s", receivedDataString);
				String[] splitRequest = receivedDataString.split("\r\n");
				int responseCode = generateResponseCode(receivedDataString, utility, splitRequest);
				String fileContent = "";

				switch (responseCode) {
				case 0:
					fileContent = fileRead(splitRequest[1], utility);
					responseToBeSent = generateResponseMessage(responseCode, fileContent, utility);
					break;
				case 1:
					responseToBeSent = generateResponseMessage(responseCode, fileContent, utility);
					break;
				// Case 2: Malformed request
				case 2:
					responseToBeSent = generateResponseMessage(responseCode, fileContent, utility);
					break;
				// Case 3: Non-existent file
				case 3:
					responseToBeSent = generateResponseMessage(responseCode, fileContent, utility);
					break;
				// Case 4: Wrong protocol version
				case 4:
					responseToBeSent = generateResponseMessage(responseCode, fileContent, utility);
					break;
				// Any other response code
				default:
					System.out.print("\nWrong response code generated!");
					System.exit(0);
				}// end of switch()

				System.out.printf("\n\nSent response : \n" + responseToBeSent);
				responseToBeSentInBytes = utility.messageInBytes(responseToBeSent);// convert response message to bytes
				ipAddressOfClient = receivedData.getAddress();
				DatagramPacket response = new DatagramPacket(responseToBeSentInBytes, responseToBeSentInBytes.length,
						ipAddressOfClient, receivedData.getPort());
				serverSocket.send(response);
			} // end of while()

		} // end of try{}
		catch (Exception e) {
			// Did not receive request from client
			e.printStackTrace();
			System.out.println("There is an error in the server :");
		}

	}

	public static String receiveRequest(byte[] receivedRequest, DatagramSocket serverSocket,
			DatagramPacket receivedData) throws Exception {
		serverSocket.receive(receivedData);// receive the request bytes via the server socket
		System.out.print("Received request bytes from client : ");
		for (int i = 0; i < receivedData.getLength(); i++)
			System.out.printf("%d,", receivedRequest[i]);
		return new String(receivedRequest, 0, receivedData.getLength());// Convert the received bytes to string
	}

	public static int generateResponseCode(String receivedDataString, ClientServerUtility utility,
			String[] splitRequest) throws Exception {
		Boolean requestIntegrityMatches = utility.isIntegrityValueOfMessageCorrect(receivedDataString, "request");
		String[] firstline = splitRequest[0].split("/");
		String filename = splitRequest[1];
		int responseCode = 0;
		if (!requestIntegrityMatches)
			responseCode = 1;
		else {
			String versionnumber = (firstline[1].substring(0, 3));
			if (!versionnumber.equals("1.0"))
				responseCode = 4;
			else if (((splitRequest[0] == null || splitRequest[1] == null || splitRequest[2] == null)
					|| (!(firstline[0].equals("ENTS")) || (firstline[1].compareTo("1.0 Request") == 1)))
					|| (!utility.isFileNameSyntaxCorrect(filename, "response")))
				responseCode = 2;
			else if ((!(filename.equals("file_A.txt")) && !(filename.equals("file_B.txt"))
					&& !(filename.equals("file_C.txt"))) || (fileRead(filename, utility).equals("File not Present")))
				responseCode = 3;
		}
		return responseCode;
	}

	public static String generateResponseMessage(int responseCode, String fileContent, ClientServerUtility utility) {
		String firstLineToSend = "ENTS/1.0 Response\r\n";
		String responseToBeSent = "";
		if (responseCode == 0)
			responseToBeSent = firstLineToSend + responseCode + "\r\n" + fileContent.length() + "\r\n" + fileContent;
		else
			responseToBeSent = firstLineToSend + responseCode + "\r\n" + "0" + "\r\n";
		String integrityValueToSend = utility.getIntegrityCheckValue(responseToBeSent);
		return (responseToBeSent = responseToBeSent + integrityValueToSend + "\r\n");
	}

	public static String fileRead(String fileName, ClientServerUtility utility) throws Exception {
		FileReader fr = null;// FileReader object
		try {

			fr = new FileReader(fileName);

		}

		catch (FileNotFoundException e) {
			// If the requested file was not found
			System.out.println("\nThe requested file is not present in the server. ");
			return "File not Present";
		}
		BufferedReader br = new BufferedReader(fr);// To read characters from FileReader object
		try {
			StringBuilder fileContent = new StringBuilder();// Read the contents of the files line by line and store in
															// a String
			String line = br.readLine();// Read the first line
			while (line != null) {
				fileContent.append(line);// add to the fileContent String
				fileContent.append(System.getProperty("line.separator"));// Append the line separator used by the
																			// system.
				line = br.readLine();
			}
			return fileContent.toString();
		} catch (IOException e) {
			// When file exists in the given path but is empty.
			System.out.print("\nNo contents in the file!!");
			System.exit(0);
		}
		return "";
	}// end of fileRead()

}// end of class Server
