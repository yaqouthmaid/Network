import java.io.*;
import java.net.*;

class Server_tcp {
	public static void main(String args[]) throws Exception {

		int firsttime = 1;
		String clientSentence;
		String clientSentence2;

		String capitalizedSentence = "";
		ServerSocket ss = new ServerSocket(6666);
		Socket s = ss.accept();

		while (true) {
			BufferedReader inFromClient = new BufferedReader(new InputStreamReader(s.getInputStream()));
			DataOutputStream outToClient = new DataOutputStream(s.getOutputStream());
			clientSentence = inFromClient.readLine();

			if (clientSentence.equals("file_A.txt") || clientSentence.equals("file_B.txt")
					|| clientSentence.equals("file_C.txt")) {
				outToClient.writeBytes(" file is Done in cipher.txt file ..... check them");

				VigenereCipher vigenereCipher = new VigenereCipher(clientSentence, "yaqouthmaid");
				vigenereCipher.encrypt();
				vigenereCipher.decrypt();

			} else
				outToClient.writeBytes("this file is not exists");


		}
	}
}
