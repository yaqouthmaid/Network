
import java.io.*;
import java.net.*;

class Client_tcp {
	public static void main(String args[]) throws Exception {
		String sentence;
		String modifiedSentence;
		String sentence2;
		String modifiedSentence2;


		System.out.println("the files that are available on the TCP server : ");
		System.out.println("file_A.txt ");
		System.out.println("file_B.txt ");
		System.out.println("file_C.txt ");
		System.out.println("write the file name :  ");


		BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
		Socket s=new Socket("localhost",6666);  
		DataOutputStream outToServer = new DataOutputStream(s.getOutputStream());
		BufferedReader inFromServer = new BufferedReader(new InputStreamReader(s.getInputStream()));

		sentence = inFromUser.readLine();
		outToServer.writeBytes(sentence + "\n");
		modifiedSentence = inFromServer.readLine();

		System.out.println("FROM SERVER:" + modifiedSentence);
		System.out.println("file is Done in cipher.txt file ..... check them");


	
	}
}
