
public class ClientServerUtility {
	public byte[] messageInBytes(String assembledMessage) {
		byte[] messageBytes = assembledMessage.getBytes();
		int byteToInteger; 
		System.out.print("\nMessage to be sent in byte form: ");
		for(int i=0; i<messageBytes.length; i++) {
			byteToInteger = messageBytes[i] & 0xff;
			System.out.printf("%d,", byteToInteger);
		}
		return messageBytes;
	}
	public boolean isFileNameSyntaxCorrect(String file, String typeOfMessage) {	
		if(file.contains(Character.toString('.'))) {
			int dot = file.indexOf(".");
			String name = file.substring(0, dot);
			String extension = file.substring(dot+1, file.length());	
			if(name.matches("^[a-zA-Z][a-z A-Z 0-9_]*$")) {
				if(extension.matches("^[a-z A-Z 0-9]*$")) {
			    return true;
				}
				else
					if(typeOfMessage.equals("request"))
					  throw new IllegalArgumentException("The sytax of the extension part of the file name is wrong!");
			}
			else
				if(typeOfMessage.equals("request"))
				  throw new IllegalArgumentException("The sytax of the name part of the file name is wrong!");
		}	
		if(typeOfMessage.equals("request"))
		  throw new IllegalArgumentException("The file name must contain a period (.) between the name and extension.");
		
		return false;
	}
	public String getIntegrityCheckValue(String assembledRequest) {
		String valueInCharacterForm = ""; 
		int[] integrityCheckData = new int[8000];
    int asciiValue1,asciiValue2;  
    String binary, binary1, binary2;
    int numberOfWords=0;
    for(int i=0;i<assembledRequest.length();i=i+2)
    {	
      if(i>assembledRequest.length())
    	  break; 
      asciiValue1=assembledRequest.charAt(i); 
      if((i==assembledRequest.length()-1)&&(assembledRequest.length()%2!=0))
	      asciiValue2=0; 	
	    else
	      asciiValue2=assembledRequest.charAt(i+1);//The odd numbered characters
    
      binary1 = Integer.toBinaryString(asciiValue1);
      binary2 = Integer.toBinaryString(asciiValue2);
      binary1=String.format("%8s", binary1).replace(' ', '0');
      binary2=String.format("%8s", binary2).replace(' ', '0');
      binary=binary1+binary2;
      int binaryWordToInt = Integer.parseInt(binary, 2);
      integrityCheckData[i/2]=binaryWordToInt;
      numberOfWords++;
    }
    int s=0; 
    for (int i=0;i<numberOfWords;i++)
    {
    	int index=s^integrityCheckData[i];
    	s=(7919*index)%65536;
    }
      valueInCharacterForm=String.valueOf(s);
      if(!valueInCharacterForm.matches("^[0-9]*$")) { 
  			System.out.print("\nIntegrity check value is incorrect!");
  			System.exit(0);
  		}
		return valueInCharacterForm;
	}
	public Boolean isIntegrityValueOfMessageCorrect(String receivedMessage, String typeofMessage) {
		String[] splitMessage = receivedMessage.split("\r\n"); 
		String messageWithoutIntegrityValue = ""; 
		String integrity = "";
		
		if(typeofMessage.equals("response"))
		{
			String contentAndIntegrityValue = "";
		  for(int i=0; i<3; i++) {
			  messageWithoutIntegrityValue = messageWithoutIntegrityValue + splitMessage[i] + "\r\n";
		  }
		  for(int i=3; i<splitMessage.length-1; i++) {
			  contentAndIntegrityValue = contentAndIntegrityValue + splitMessage[i] + "\r\n";
		  }
		  int contentLength = Integer.parseInt(splitMessage[2]); 
		  String fileContent = contentAndIntegrityValue.substring(0, contentLength); 
		  messageWithoutIntegrityValue = messageWithoutIntegrityValue + fileContent;
		  integrity = contentAndIntegrityValue.substring(contentLength);
		}
		else if(typeofMessage.equals("request")) {
		  integrity = splitMessage[2];
			messageWithoutIntegrityValue = splitMessage[0]+"\r\n"+splitMessage[1]+"\r\n";
		}
		
		integrity = integrity.replaceAll("\\r\\n", "");
		if(getIntegrityCheckValue(messageWithoutIntegrityValue).matches(integrity)) {
			System.out.print("\n\nThe calculated integrity value of the message matches the integrity check field of the response");
			return true;
		}
		System.out.print("\n\nThe calculated integrity value of the message does not match the integrity check field of the response");
		return false;
	}
	
}